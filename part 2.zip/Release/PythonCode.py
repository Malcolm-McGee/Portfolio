import re
import string
import os.path
from os import path


def CountAll():
    #Opens the file in read mode
    text = open("CS210_Project_Three_Input_File.txt", "r")

    #Makes an empty dirictory
    dictionary = dict()

    #Checks everyline in the input
    for line in text:
        #removes spaces or newlines 
        line = line.strip()

        #Converts everyting to lowercase 
        word = line.lower()
          
        if word in dictionary:
            #Increments the number if the word was in the dictionary
            dictionary[word] = dictionary[word] + 1
        else:
            #If its not in the dictionary it completes this to add it
            dictionary[word] = 1

    #Print all the contents of the dictionary
    for key in list (dictionary.keys()):
        print(key.capitalize(), ":", dictionary[key])

    #Closes the opened file.
    text.close()


def CountInstances(searchTerm):

    #Convert the search term to lowercase
    searchTerm = searchTerm.lower()

    text = open("CS210_Project_Three_Input_File.txt", "r")

    wordCount = 0
   
    for line in text:

        line = line.strip()
     
        word = line.lower()
        
        #Checks if the word is equal to the user search
        if word == searchTerm:
            #Increment number of times the word appears if it was equal
            wordCount += 1

    #Returns the number of times that term was found 
    return wordCount

    #Closes file
    text.close()




def CollectData():
    
    text = open("CS210_Project_Three_Input_File.txt", "r")
  
    frequency = open("frequency.dat", "w")
 
    dictionary = dict()

    for line in text:
        line = line.strip()

        word = line.lower()
        
        if word in dictionary:
            dictionary[word] = dictionary[word] + 1
        else:
            dictionary[word] = 1

    for key in list (dictionary.keys()):
        frequency.write(str(key.capitalize()) + " " + str(dictionary[key]) + "\n")

    text.close()
    frequency.close()